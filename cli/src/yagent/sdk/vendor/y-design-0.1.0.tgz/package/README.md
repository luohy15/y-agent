# @y/design

React 19 Table primitives shared by y-agent and y-module. The package ships ESM and TypeScript declarations only; it does not ship CSS or own the theme.

The consuming app supplies the existing Solarized `sol-*` color tokens, mono font and 4px `--radius`. Tailwind CSS v4 must scan the installed package's `dist/index.js` in both the host and SDK builds. Keep each utility name as a complete string so static scanning works. No preflight, global styles, runtime host imports, or business sorting logic are included.

```tsx
import {
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableHeaderCell, TableRow, TableSortHeader,
} from "@y/design";

<TableContainer>
  <Table>
    <caption className="sr-only">Slowest routes</caption>
    <TableHead>
      <TableRow>
        <TableSortHeader direction="desc" onSort={() => setSort("route")}>Route</TableSortHeader>
        <TableHeaderCell>Requests</TableHeaderCell>
      </TableRow>
    </TableHead>
    <TableBody>
      {rows.map((row) => (
        <TableRow key={row.route}>
          <TableCell>{row.route}</TableCell>
          <TableCell align="right">{row.requests}</TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</TableContainer>
```

`Table` accepts native table props and an accessible `caption`. All primitives accept native element props and React 19 refs; classes can be extended via `className`. Use `TableContainer` only when the caller does not already own a scroll container. `TableSortHeader` renders a keyboard-operable button and reflects the active direction in `aria-sort`; the caller owns sort state and data ordering. `TableCell align="right"` applies `tabular-nums` for numeric columns.

Run `npm ci && npm run build && npm pack --dry-run` before packaging. No remote distribution is configured yet.
