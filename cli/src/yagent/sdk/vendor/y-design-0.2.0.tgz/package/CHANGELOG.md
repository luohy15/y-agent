# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-09-23

### Added

- `Badge`: non-interactive pill with `neutral`, `info`, `success`, `warning`, and `danger` tones and an optional leading `icon`.
- `Select`: native `<select>` with a visible label, option list, `onValueChange`, and an optional error wired through `aria-invalid` and `aria-describedby`.
- `DateRangeInput`: two native date inputs plus Apply. Empty, reversed, out-of-range, and caller `error` states disable Apply and do not call `onApply`. Enter submits a valid range.
- README sections for the three components and the host `.y-field` CSS dependency.
- `TableHeaderCell`, `TableCell`, and `TableSortHeader` `align` now accepts `center` in addition to `left` and `right`. `center` emits `text-center` from the primitive. Left and right output is unchanged. Appended `className` is still concatenation only, so it is not a way to override alignment.

## [0.1.0] - 2026-09-23

### Added

- Table primitives: `TableContainer`, `Table`, `TableHead`, `TableBody`, `TableRow`, `TableHeaderCell`, `TableCell`, `TableSortHeader`.
- ESM and TypeScript declarations only. No CSS. Tailwind utility class names are complete strings for static scanning.
