# @y/design

React 19 Table primitives shared by y-agent and y-module. The package ships ESM and TypeScript declarations only; it does not ship CSS or own the theme.

The consuming app supplies the existing Solarized `sol-*` color tokens, mono font and 4px `--radius`. Tailwind CSS v4 must scan the installed package's `dist/index.js` in both the host and SDK builds. Keep each utility name as a complete string so static scanning works. No preflight, global styles, runtime host imports, or business sorting logic are included.

```tsx
import {
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableHeaderCell, TableRow, TableSortHeader,
} from "@y/design";

<TableContainer>
  <Table>
    <caption className="sr-only">Slowest routes</caption>
    <TableHead>
      <TableRow>
        <TableSortHeader direction="desc" onSort={() => setSort("route")}>Route</TableSortHeader>
        <TableHeaderCell>Requests</TableHeaderCell>
      </TableRow>
    </TableHead>
    <TableBody>
      {rows.map((row) => (
        <TableRow key={row.route}>
          <TableCell>{row.route}</TableCell>
          <TableCell align="right">{row.requests}</TableCell>
        </TableRow>
      ))}
    </TableBody>
  </Table>
</TableContainer>
```

`Table` accepts native table props and an accessible `caption`. All primitives accept native element props and React 19 refs; classes can be extended via `className`. Use `TableContainer` only when the caller does not already own a scroll container. `TableSortHeader` renders a keyboard-operable button and reflects the active direction in `aria-sort`; the caller owns sort state and data ordering. `TableHeaderCell` and `TableCell` take `align` of `left` (default), `right`, or `center`. `align="right"` applies `tabular-nums` for numeric columns. `align="center"` emits `text-center` as the cell's own alignment class. Appended `className` values are concatenated, not guaranteed to win a same-property Tailwind conflict, so centering a column goes through `align` rather than `className="text-center"`. `TableSortHeader` accepts the same `align` values and centers its button when `align="center"`.

## Badge

Non-interactive `<span>` pill. `tone` is `neutral` (default), `info`, `success`, `warning`, or `danger`. `icon` is an optional leading slot. Native span props and a React 19 ref pass through; `className` is appended.

```tsx
import { Badge } from "@y/design";

<Badge tone="success" title="API key">key</Badge>
```

The caller owns any business-to-tone mapping. The five tone class pairs are fixed and must stay as complete utility strings.

## Select

Native `<select>` with a visible label and an optional error. Arrow chrome stays the browser default. Props: `label`, `value`, `options` (`{ value, label, disabled? }`), `onValueChange(value)`, optional `disabled` and `error`. Other native select props and a React 19 ref pass through, except `value`, `onChange`, and `children`.

```tsx
import { Select } from "@y/design";

<Select
  label="Method"
  value={method}
  options={[{ value: "", label: "All methods" }, { value: "GET", label: "GET" }]}
  onValueChange={setMethod}
  error={methodError}
/>
```

The label uses `htmlFor` and, when `error` is set, the select sets `aria-invalid` and `aria-describedby` pointing at the error text.

## DateRangeInput

Two native `type="date"` inputs plus an Apply button, wrapped in a form so Enter submits. `value` is `{ from, to }` of `YYYY-MM-DD` strings or empty strings (never `Date`). `onChange(next)` reports draft edits. `onApply(range)` fires only for a structurally valid range. Optional `min` and `max` use the same string format. `labels` overrides the `from`, `to`, and `apply` text. `error` is a caller-supplied business message. `disabled` disables both inputs and Apply.

```tsx
import { DateRangeInput } from "@y/design";

<DateRangeInput
  value={draft}
  onChange={setDraft}
  onApply={(range) => load(range)}
  max={today}
/>
```

Apply stays disabled, and `onApply` does not run, when either date is empty, `from > to` (ISO string compare), a date falls outside `min` / `max`, or `error` is set. The blocking reason is one line of text; values are not rewritten or filled with today. Each input has its own label and shares `aria-describedby` with that reason. Presets, time zones, and API boundary conversion stay in the caller.

## Host CSS

`Select` and `DateRangeInput` put the class `y-field` on the native controls. The package does not ship that rule. The host must keep the append-only `.y-field` contract (background, border, focus ring) from the y-agent design language. `Badge` does not use `.y-field`.

Run `npm ci && npm run build && npm pack --dry-run` before packaging. No remote distribution is configured yet.
